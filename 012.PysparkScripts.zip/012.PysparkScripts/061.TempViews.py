# Databricks notebook source
df = (spark.read.format("csv")
.option("path","/FileStore/tables/Products.csv")
.option("header",True)
.option("inferschema",True)
.load())
display(df)

# COMMAND ----------

df.createTempView("vwProducts")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from vwProducts

# COMMAND ----------

# MAGIC %sql
# MAGIC show databases

# COMMAND ----------

# MAGIC %sql
# MAGIC create database mydb

# COMMAND ----------

display(spark.catalog.listDatabases())

# COMMAND ----------

spark.catalog.listTables()


# COMMAND ----------

# MAGIC %sql
# MAGIC show tables

# COMMAND ----------

df.createTempView("vwProducts")

# COMMAND ----------

df.createOrReplaceTempView("vwProducts")

# COMMAND ----------

df.createOrReplaceGlobalTempView("vwProductsGl")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from global_temp.vwProductsGl

# COMMAND ----------

spark.catalog.dropTempView("vwProducts")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from vwProducts

# COMMAND ----------

spark.catalog.dropGlobalTempView("vwProductsGl")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from global_temp.vwProductsGl

# COMMAND ----------

