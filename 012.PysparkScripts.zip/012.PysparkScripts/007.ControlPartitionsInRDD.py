# Databricks notebook source
lst = [1,2,3,4,5]
rdd1 = sc.parallelize(lst)
rdd1.collect()

# COMMAND ----------

rdd1.getNumPartitions()

# COMMAND ----------

rdd2=sc.parallelize(lst,5)
rdd2.collect()


# COMMAND ----------

rdd2.getNumPartitions()

# COMMAND ----------

rdd2.glom().collect()

# COMMAND ----------

rdd3 = sc.parallelize(lst,3)
rdd3.glom().collect()

# COMMAND ----------

