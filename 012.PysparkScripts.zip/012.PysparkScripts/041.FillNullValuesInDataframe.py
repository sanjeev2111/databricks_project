# Databricks notebook source
df = (spark.read.format("csv")
.option("path","/FileStore/tables/EmployeeNulls.csv")
.option("header",True)
.option("inferschema",True)
.load())
display(df)

# COMMAND ----------

df2=df.na.fill(0)
display(df2)

# COMMAND ----------

df2=df.na.fill("na")
display(df2)

# COMMAND ----------

df2=df.na.fill("na").na.fill(0)
display(df2)

# COMMAND ----------

from pyspark.sql.functions import *

# COMMAND ----------

df3=df.withColumn("id",coalesce("id",lit(0)))
display(df3)

# COMMAND ----------

