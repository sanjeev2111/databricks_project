# Databricks notebook source
# MAGIC %md ## Broadcast Variables
# MAGIC
# MAGIC 1. Broadcast variables are shared variables in spark
# MAGIC 2. It is a read only variable which is cached on each machine in a cluster
# MAGIC 3. Spark uses efficient algorithms to distribute broadcasted variables to reduce communication costs
# MAGIC

# COMMAND ----------

data = [(1,"India",10000),(2,"UK",50000),(3,"US",100000),(4,"FRANCE",90000)]

# COMMAND ----------

rdd = sc.parallelize(data)
rdd.collect()

# COMMAND ----------

products={1:"Phone",2:"Ipad",3:"Iphone",4:"Laptop"}

# COMMAND ----------

products[1]

# COMMAND ----------

prodbc = sc.broadcast(products)

# COMMAND ----------

prodbc.value

# COMMAND ----------

type(prodbc)

# COMMAND ----------

rdd2 = rdd.map(lambda x : (x[0],prodbc.value[x[0]],x[1],x[2]))
rdd2.collect()

# COMMAND ----------

