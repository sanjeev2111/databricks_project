# Databricks notebook source
spark.conf.set(
    "fs.azure.account.key.cdudevmyadls.dfs.core.windows.net",
    "FEMAM5XrlDGEl0hdGLvyvwklbzT98jYvdYuy+1JMpOr60QNjJ4TpAjr+ZJ2RGoWF4l8yGjbhNz9G+AStlavy9g==")



# COMMAND ----------

df = (spark.read.format("csv")
.option("path","abfss://mycontainer@cdudevmyadls.dfs.core.windows.net/CSVfiles/tripdata/tripdataNew.csv")
.option("header",True)
.option("inferschema",True)
.load())
display(df)

# COMMAND ----------

display(dbutils.fs.ls("/FileStore/tables/PaymentTypes.csv"))

# COMMAND ----------

ptypedf = (spark.read.format("csv")
.option("path","/FileStore/tables/PaymentTypes.csv")
.option("header",True)
.option("inferschema",True)
.load())
display(ptypedf)

# COMMAND ----------

joindf = df.join(ptypedf,df.payment_type == ptypedf.PaymentTypeID)
display(joindf)

# COMMAND ----------

spark.conf.get("spark.sql.autoBroadcastJoinThreshold")

# COMMAND ----------

10485760/1024/1024

# COMMAND ----------

joindf.explain(True)

# COMMAND ----------

spark.conf.get("spark.sql.broadcastTimeout")

# COMMAND ----------

from pyspark.sql.functions import broadcast

# COMMAND ----------

joindf = df.join(broadcast(ptypedf),df.payment_type == ptypedf.PaymentTypeID)
display(joindf)

# COMMAND ----------

spark.conf.set("spark.sql.autoBroadcastJoinThreshold",20*1024*1024)

# COMMAND ----------

spark.conf.get("spark.sql.autoBroadcastJoinThreshold")

# COMMAND ----------

spark.conf.set("spark.sql.autoBroadcastJoinThreshold",-1)

# COMMAND ----------

spark.conf.get("spark.sql.autoBroadcastJoinThreshold")

# COMMAND ----------

spark.conf.set("spark.sql.autoBroadcastJoinThreshold",40)

# COMMAND ----------

spark.conf.get("spark.sql.autoBroadcastJoinThreshold")

# COMMAND ----------

spark.conf.get("spark.sql.join.preferSortMergeJoin")

# COMMAND ----------

joindf2 = df.join(ptypedf,df.payment_type == ptypedf.PaymentTypeID)
display(joindf2)

# COMMAND ----------

joindf2.explain(True)

# COMMAND ----------

spark.conf.set("spark.sql.join.preferSortMergeJoin",False)

# COMMAND ----------

spark.conf.get("spark.sql.join.preferSortMergeJoin")

# COMMAND ----------

joindf3 = df.join(ptypedf,df.payment_type == ptypedf.PaymentTypeID)
display(joindf3)

# COMMAND ----------

joindf3.explain(True)

# COMMAND ----------


