# Databricks notebook source
df = (spark.read.format("csv")
.option("path","/FileStore/tables/Products.csv")
.option("header",True)
.option("inferschema",True)
.load())
display(df)

# COMMAND ----------

df2=df.groupBy("EnglishProductName").pivot("Country").sum("SalesAmount")
display(df2)

# COMMAND ----------

df3=df.groupBy("ProductKey","EnglishProductName").pivot("Country").sum("SalesAmount")
display(df3)

# COMMAND ----------

help(df2.unpivot)


# COMMAND ----------

df4=df2.unpivot("EnglishProductName",["Australia"],"Country","Salesamount")
display(df4)

# COMMAND ----------

df4=df2.unpivot("EnglishProductName",["Australia","France","Canada"],"Country","Salesamount")
display(df4)

# COMMAND ----------

df5=df3.unpivot(["ProductKey","EnglishProductName"],["Australia","France","Canada"],"Country","Salesamount")
display(df5)

# COMMAND ----------

df5=df3.unpivot(["ProductKey","EnglishProductName"],["Australia","France","Canada"],"Country","Salesamount").dropna()
display(df5)

# COMMAND ----------

