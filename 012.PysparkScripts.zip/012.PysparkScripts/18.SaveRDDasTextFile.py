# Databricks notebook source
rdd1=sc.textFile("/FileStore/tables/001_Wordcount.txt")
rdd2 = rdd1.flatMap(lambda x : x.split(" "))
rdd3 = rdd2.map(lambda y : (y,1))
rdd4 = rdd3.reduceByKey(lambda x,y: x + y)
rdd4.collect()

# COMMAND ----------

rdd4.saveAsTextFile("/FileStore/tables/RDDOutput")

# COMMAND ----------

rdd4.getNumPartitions()

# COMMAND ----------

rdd11=sc.textFile("/FileStore/tables/RDDOutput/part-00000")
rdd11.collect()

# COMMAND ----------

rdd11=sc.textFile("/FileStore/tables/RDDOutput/part-00001")
rdd11.collect()

# COMMAND ----------

