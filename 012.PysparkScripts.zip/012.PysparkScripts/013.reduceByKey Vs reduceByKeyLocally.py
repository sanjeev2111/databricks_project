# Databricks notebook source
rdd1=sc.textFile("/FileStore/tables/001_Wordcount.txt")
rdd2 = rdd1.flatMap(lambda x : x.split(" "))
rdd3 = rdd2.map(lambda y : (y,1))
rdd4 = rdd3.reduceByKey(lambda x,y: x + y)
rdd4.collect()

# COMMAND ----------

help(rdd3.reduceByKey)

# COMMAND ----------

help(rdd3.reduceByKeyLocally)

# COMMAND ----------

dct = rdd3.reduceByKeyLocally(lambda x,y : x + y)
type(dct)
print(dct)

# COMMAND ----------

