# Databricks notebook source
df = (spark.read.format("csv")
.option("path","/FileStore/tables/Products.csv")
.option("header",True)
.option("inferschema",True)
.load())
display(df)

# COMMAND ----------

df.write.format("delta").option("path","/FileStore/tables/DeltaFormat").save()

# COMMAND ----------

df2 = (spark.read.format("json")
.option("path","/FileStore/tables/DeltaFormat/_delta_log/00000000000000000000.json")
.load())
display(df2)

# COMMAND ----------

df3 = (spark.read.format("delta")
.option("path","/FileStore/tables/DeltaFormat/")
.load())
display(df3)

# COMMAND ----------

df3 = (spark.read.format("delta")
.option("path","/FileStore/tables/park/")
.load())
display(df3)

# COMMAND ----------

df3 = (spark.read.format("parquet")
.option("path","/FileStore/tables/park/")
.load())
display(df3)

# COMMAND ----------

