# Databricks notebook source
rdd1 = sc.parallelize([1,2,3,4,5,6,7,8,9,10])
rdd1.collect()

# COMMAND ----------

rdd1.getNumPartitions()


# COMMAND ----------

rdd1.glom().collect()

# COMMAND ----------

help(rdd1.coalesce)

# COMMAND ----------

rdd2=rdd1.coalesce(4)


# COMMAND ----------

rdd2.collect()

# COMMAND ----------

rdd2.glom().collect()

# COMMAND ----------

[[1], [2], [3], [4, 5], [6], [7], [8], [9, 10]]

# COMMAND ----------

rdd3=rdd1.coalesce(10)
rdd3.glom().collect()

# COMMAND ----------

help(rdd1.repartition)

# COMMAND ----------

rdd4 = rdd1.repartition(4)
rdd4.collect()

# COMMAND ----------

rdd4.glom().collect()

# COMMAND ----------

rdd5=rdd1.repartition(16)
rdd5.collect()

# COMMAND ----------

rdd5.glom().collect()

# COMMAND ----------

