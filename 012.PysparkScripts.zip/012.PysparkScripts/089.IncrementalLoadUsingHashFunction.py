# Databricks notebook source
# MAGIC %run /Workspace/Users/yusufdidighar@cloudanddatauniverse.com/JDBC/Utilities

# COMMAND ----------

spark.conf.set("fs.azure.account.key","dfFLxusQns3P6A3PfS9U2BbfVdbMAQldUQyPy84JVFxZJKywe3CXa1KbSSBLDqELoqa5IN/xB5Vr+AStvZYQQA==")

# COMMAND ----------

ADLS_Path = "abfss://mycontainer@myadlstraining.dfs.core.windows.net/IncrementalLoad/Sales/"

# COMMAND ----------

from pyspark.sql.functions import col, xxhash64, concat_ws

# COMMAND ----------

source_df = (spark.read.format("csv")
            .option("path",ADLS_Path)
            .option("header","true")
            .option("inferschema","true")
            .load().withColumn("SalesDate",col("SalesDate").cast("timestamp"))
            .withColumn("SalesAmount",col("SalesAmount").cast("decimal(19,4)"))
)
display(source_df)


# COMMAND ----------

target_df = ReadTableFromDatabase("dbo.Sales")
display(target_df)

# COMMAND ----------

source_hash_df = source_df.withColumn("HashKey",xxhash64(concat_ws("||", *source_df.columns)))
display(source_hash_df)

# COMMAND ----------


# target_hash_df = target_df.withColumn("HashKey",xxhash64(concat_ws("||", "SalesDate","Country")))
target_hash_df = target_df.withColumn("HashKey",xxhash64(concat_ws("||", *target_df.columns)))
display(target_hash_df)


# COMMAND ----------

delta_load = source_hash_df.join(target_hash_df,on="HashKey",how="left_anti")
display(delta_load)

# COMMAND ----------

final_df = delta_load.drop("HashKey")

# COMMAND ----------

WriteDataframeToDatabaseMode(final_df,"dbo.Sales","append")