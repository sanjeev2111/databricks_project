# Databricks notebook source
dbutils.help()

# COMMAND ----------

dbutils.fs.help()

# COMMAND ----------

dbutils.fs.help("ls")

# COMMAND ----------

display(dbutils.fs.ls("/FileStore/tables"))

# COMMAND ----------

display(dbutils.fs.ls("/FileStore/tables/WriteModes"))

# COMMAND ----------

display(dbutils.fs.ls("/FileStore/tables/SalesMultiline.csv"))

# COMMAND ----------

dbutils.fs.help("mkdirs")

# COMMAND ----------

dbutils.fs.mkdirs("/FileStore/Myfolder")

# COMMAND ----------

dbutils.fs.mkdirs("/FileStore/Myfolder")

# COMMAND ----------

dbutils.fs.mkdirs("/FileStore/Myfolder2/test")

# COMMAND ----------

dbutils.fs.rm("/FileStore/Myfolder")

# COMMAND ----------

dbutils.fs.rm("/FileStore/Myfolder")

# COMMAND ----------

dbutils.fs.rm("/FileStore/tables/WriteModes2",recurse=True)

# COMMAND ----------

dbutils.fs.rm("/FileStore/tables/EmployeesSpace.csv")

# COMMAND ----------

dbutils.fs.cp("/FileStore/tables/Output","/FileStore/tables/Output2",recurse=True)

# COMMAND ----------

dbutils.fs.mv("/FileStore/tables/Output","/FileStore/tables/Output2",recurse=True)

# COMMAND ----------

