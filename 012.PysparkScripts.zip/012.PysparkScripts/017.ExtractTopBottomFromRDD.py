# Databricks notebook source
rdd1=sc.textFile("/FileStore/tables/001_Wordcount.txt")
rdd2 = rdd1.flatMap(lambda x : x.split(" "))
rdd3 = rdd2.map(lambda y : (y,1))
rdd4 = rdd3.reduceByKey(lambda x,y: x + y)
rdd4.collect()

# COMMAND ----------

help(rdd4.first)

# COMMAND ----------

rdd4.first()

# COMMAND ----------

type(rdd4.first())

# COMMAND ----------

rdd4.take(2)

# COMMAND ----------

type(rdd4.take(2))

# COMMAND ----------

rdd4.sortBy(lambda x:x[1],ascending=False).take(2)

# COMMAND ----------

rdd4.sortBy(lambda x:x[1]).take(3)

# COMMAND ----------

rdd4.keys().collect()

# COMMAND ----------

rdd4.values().collect()

# COMMAND ----------

