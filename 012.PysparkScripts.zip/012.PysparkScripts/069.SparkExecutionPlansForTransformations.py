# Databricks notebook source
df = (spark.read.format("csv")
.option("path","/FileStore/tables/Products.csv")
.option("header",True)
.option("inferschema",True)
.load())
display(df)

# COMMAND ----------

df.explain()

# COMMAND ----------

df.explain(True)

# COMMAND ----------

df2 = df.filter("country='India'")
display(df2)

# COMMAND ----------

df2.explain(True)

# COMMAND ----------

from pyspark.sql.functions import * 

# COMMAND ----------

df3 = df.withColumn("CountryOfOrigin",lit("India"))
display(df3)

# COMMAND ----------

df3.explain(True)

# COMMAND ----------

df4 = df.withColumn("CountryOfOrigin",lit("India")).filter("Country='France'")
display(df4)

# COMMAND ----------

df4.explain(True)

# COMMAND ----------

df4.rdd.toDebugString().splitlines()

# COMMAND ----------

df5=df.select(sum("SalesAmount")).alias("TotalSales")
display(df5)

# COMMAND ----------

df5.explain(True)

# COMMAND ----------

df6 = df.groupBy("Country").sum("SalesAmount")
display(df6)

# COMMAND ----------

df6.explain(True)

# COMMAND ----------

spark.conf.get("spark.sql.shuffle.partitions")

# COMMAND ----------

spark.conf.set("spark.sql.shuffle.partitions",50)

# COMMAND ----------

spark.conf.get("spark.sql.shuffle.partitions")

# COMMAND ----------

df6 = df.groupBy("Country").sum("SalesAmount")
display(df6)

# COMMAND ----------

df6.explain(True)

# COMMAND ----------

countryDisdf = df.select("Country").distinct()
display(countryDisdf)
countryDisdf.explain(True)

# COMMAND ----------

df7 = spark.range(1000000)
display(df7)
df7.explain(True)

# COMMAND ----------

df8 = spark.range(1000000)
df9 = df8.selectExpr("id * 10 as id")
df9.explain(True)

# COMMAND ----------

df10=df8.repartition(6)
df10.explain(True)

# COMMAND ----------

x=100

# COMMAND ----------


