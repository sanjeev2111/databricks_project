# Databricks notebook source
x = 100

# COMMAND ----------

def double(x):
    return x * 2

# COMMAND ----------


