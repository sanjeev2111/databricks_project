# Databricks notebook source
df = (spark.read.format("csv")
.option("path","/FileStore/tables/Employees.csv")
.option("header",True)
.option("inferschema",True)
.load())
display(df)

# COMMAND ----------

help(df.write)

# COMMAND ----------

df.write.format("csv").option("path","/FileStore/tables/WriteModes").save()

# COMMAND ----------

df2 = (spark.read.format("csv")
.option("path","/FileStore/tables/WriteModes")
.option("header",True)
.option("inferschema",True)
.load())
display(df2)

# COMMAND ----------



# COMMAND ----------

df.write.format("csv").option("path","/FileStore/tables/WriteModes").option("header",True).save()

# COMMAND ----------

(df.write.format("csv")
.option("path","/FileStore/tables/WriteModes")
.option("header",True)
.mode("append")
.save())

# COMMAND ----------

df2 = (spark.read.format("csv")
.option("path","/FileStore/tables/WriteModes/part-00000-tid-1704317011183956692-243beb99-3de5-44b4-b211-7daf5a319b6f-207-1-c000.csv")
.option("header",True)
.option("inferschema",True)
.load())
display(df2)


# COMMAND ----------

(df.write.format("csv")
.option("path","/FileStore/tables/WriteModes")
.option("header",True)
.mode("overwrite")
.save())

# COMMAND ----------

(df.write.format("csv")
.option("path","/FileStore/tables/WriteModes")
.option("header",True)
.mode("ignore")
.save())

# COMMAND ----------

(df.write.format("csv")
.option("path","/FileStore/tables/WriteModes")
.option("header",True)
.mode("errorifexists")
.save())

# COMMAND ----------

