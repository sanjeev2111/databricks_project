# Databricks notebook source
# MAGIC %sql
# MAGIC DROP TABLE Incremental_Load_Mappings

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE Incremental_Load_Mappings(
# MAGIC   TableName string,
# MAGIC   WaterMarkColumn string,
# MAGIC   WateMarkValue DATE
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO Incremental_Load_Mappings(TableName, WaterMarkColumn, WateMarkValue)
# MAGIC VALUES
# MAGIC ('dbo.Sales', 'SalesDate', '2015-01-01');
# MAGIC
# MAGIC SELECT * FROM Incremental_Load_Mappings;

# COMMAND ----------

maxDate = spark.table("Incremental_Load_Mappings").select("WateMarkValue").where("TableName = 'dbo.Sales'").collect()
maxDate[0]['WateMarkValue']

# COMMAND ----------

# MAGIC %run /Workspace/Users/yusufdidighar@cloudanddatauniverse.com/JDBC/Utilities

# COMMAND ----------

spark.conf.set("fs.azure.account.key","XMO4VpW0vPI5kCzCeGVcLq8mQs/t0Mg4VI1/tKTh3NLm/Kv6B3u9QzBg8NCfG2YxAwPMkhv1w9dc+AStFi4pOw==")

# COMMAND ----------

df = (spark.read.format("csv")
      .option("header", "true")
      .option("inferSchema", "true")
      .load("abfss://mycontainer@myadlstraining.dfs.core.windows.net/IncrementalLoad/Sales/Sales1.csv")
)
display(df)

# COMMAND ----------

delta_load = df.filter(df.SalesDate > maxDate[0]['WateMarkValue'])
display(delta_load)

# COMMAND ----------

WriteDataframeToDatabaseMode(delta_load, "dbo.Sales", "append")


# COMMAND ----------

import pyspark.sql.functions as F

# COMMAND ----------

New_WaterMark_Value = delta_load.withColumn(
    "SalesDate", F.col("SalesDate").cast("date")
).agg(F.max("SalesDate")).collect()[0][0]
print(New_WaterMark_Value)

# COMMAND ----------

query = f"""
UPDATE incremental_load_mappings 
SET WateMarkValue = CAST('{New_WaterMark_Value}' AS DATE)
WHERE TableName = 'dbo.Sales'
"""

spark.sql(query)

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM incremental_load_mappings

# COMMAND ----------

