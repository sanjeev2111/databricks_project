# Databricks notebook source
salesdf = (spark.read.format("csv")
.option("path","/FileStore/tables/Sales.csv")
.option("header",True)
.option("inferSchema",True)
.load())
display(salesdf)

# COMMAND ----------

productsdf = (spark.read.format("csv")
.option("path","/FileStore/tables/ProductsNew.csv")
.option("header",True)
.option("inferSchema",True)
.load())
display(productsdf)

# COMMAND ----------

help(salesdf.join)

# COMMAND ----------

joindf = salesdf.join(productsdf)
display(joindf)

# COMMAND ----------

joindf2 = salesdf.join(productsdf,salesdf.ProductKey == productsdf.ProductKey)
display(joindf2)

# COMMAND ----------

joindf3 = salesdf.join(productsdf,salesdf.ProductKey == productsdf.ProductKey,"inner")
display(joindf3)

# COMMAND ----------

joindf3 = salesdf.join(productsdf,salesdf.ProductKey == productsdf.ProductKey,"left")
display(joindf3)

# COMMAND ----------

joindf3 = salesdf.join(productsdf,salesdf.ProductKey == productsdf.ProductKey,"right")
display(joindf3)

# COMMAND ----------

joindf3 = salesdf.join(productsdf,salesdf.ProductKey == productsdf.ProductKey,"leftanti")
display(joindf3)

# COMMAND ----------

joindf3 = salesdf.join(productsdf,salesdf.ProductKey == productsdf.ProductKey,"leftsemi")
display(joindf3)

# COMMAND ----------

customerdf = (spark.read.format("csv")
.option("path","/FileStore/tables/Customers.csv")
.option("header",True)
.option("inferSchema",True)
.load())
display(customerdf)

# COMMAND ----------

joindf3 = salesdf.join(productsdf,salesdf.ProductKey == productsdf.ProductKey,"inner").join(customerdf,salesdf.CustomerKey == customerdf.CustomerKey,"inner")
display(joindf3)

# COMMAND ----------

joindf3 = salesdf.join(productsdf,salesdf.ProductKey == productsdf.ProductKey,"left").drop(productsdf['ProductKey'])
display(joindf3)

# COMMAND ----------

salesmultidf = (spark.read.format("csv")
.option("path","/FileStore/tables/SalesMulti.csv")
.option("header",True)
.option("inferSchema",True)
.load())
display(salesmultidf)

# COMMAND ----------

productsmultidf = (spark.read.format("csv")
.option("path","/FileStore/tables/ProductsMulti.csv")
.option("header",True)
.option("inferSchema",True)
.load())
display(productsmultidf)

# COMMAND ----------

joindfmulti = salesmultidf.join(productsmultidf,["ProductId","Country"],"inner")
display(joindfmulti)

# COMMAND ----------

productsmultidf2= productsmultidf.withColumnRenamed("ProductId","ProductKey")
display(productsmultidf2)

# COMMAND ----------

joindfmulti = salesmultidf.join(productsmultidf2,(salesmultidf.ProductId == productsmultidf2.ProductKey) & (salesmultidf.Country == productsmultidf2.Country),"inner")
display(joindfmulti)

# COMMAND ----------

joindfmulti = salesmultidf.join(productsmultidf2,(salesmultidf.ProductId == productsmultidf2.ProductKey) & (salesmultidf.Country == productsmultidf2.Country),"inner").drop("ProductKey",productsmultidf2['Country'])
display(joindfmulti)

# COMMAND ----------


