# Databricks notebook source
from pyspark.sql.functions import *

# COMMAND ----------

df = spark.range(10000000).withColumn("id2",expr("id *2"))
display(df)

# COMMAND ----------

df2 =df
display(df2)

# COMMAND ----------

joindf = df.join(df2,df.id==df2.id)
display(joindf)

# COMMAND ----------

joindf.explain(True)

# COMMAND ----------

df.write.format("parquet").mode("overwrite").bucketBy(10,"id").saveAsTable("Bucketids")

# COMMAND ----------

bucketdf = spark.table("Bucketids")

# COMMAND ----------

joindf2=df.join(bucketdf,df.id==bucketdf.id)
display(joindf2)

# COMMAND ----------

joindf2.explain(True)

# COMMAND ----------

bucketdf2 = spark.table("Bucketids")

# COMMAND ----------

joindf3=bucketdf.join(bucketdf2,bucketdf.id==bucketdf2.id)
display(joindf3)

# COMMAND ----------

joindf3.explain(True)

# COMMAND ----------

joindf4=bucketdf.join(bucketdf2,bucketdf.id2==bucketdf2.id2)
display(joindf4)

# COMMAND ----------

joindf4.explain(True)

# COMMAND ----------

x=100

# COMMAND ----------


