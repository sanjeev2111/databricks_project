# Databricks notebook source
df = (spark.read.format("csv")
.option("path","/FileStore/tables/Products.csv")
.option("header",True)
.option("inferSchema",True)
.load())
display(df)

# COMMAND ----------

df.explain()

# COMMAND ----------

df.explain(extended=True)

# COMMAND ----------


