# Databricks notebook source
df = (spark.read.format("csv")
.option("path","/FileStore/tables/Products.csv")
.option("header",True)
.option("inferschema",True)
.load())
display(df)

# COMMAND ----------

df.write.saveAsTable("tblorders")

# COMMAND ----------

# MAGIC %sql
# MAGIC describe table tblorders

# COMMAND ----------

# MAGIC %sql
# MAGIC describe detail tblorders

# COMMAND ----------

# MAGIC %sql
# MAGIC show tables

# COMMAND ----------

spark.catalog.listTables()

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table tblorders

# COMMAND ----------

# MAGIC %sql
# MAGIC create database testing

# COMMAND ----------

df.write.saveAsTable("testing.tblorders")

# COMMAND ----------

df.write.option("path","/FileStore/tables/Ext").saveAsTable("tblordersext")

# COMMAND ----------

df.write.option("path","/FileStore/tables/Ext2").saveAsTable("tblordersext")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from tblordersext

# COMMAND ----------

# MAGIC %sql
# MAGIC describe detail tblordersext

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table tblordersext

# COMMAND ----------

spark.catalog.listTables()

# COMMAND ----------

df.createTempView("vworders")

# COMMAND ----------

# MAGIC %sql
# MAGIC create table tblordersnew as
# MAGIC select * from vworders

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from tblordersnew

# COMMAND ----------

